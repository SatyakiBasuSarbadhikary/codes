#13TH FEB
mu=matrix(c(2,4,3),nrow=3)
a=matrix(c(1,2,1),nrow=3)
sigma=matrix(c(3,1,2,1,4,5,2,5,9),byrow=T,nrow=3)
exp=t(a)%*%mu
exp
variance=t(a)%*%sigma%*%a
variance
#-------------------------------------------------------------------
mu=matrix(c(2,4,3),nrow=3)
a=matrix(c(5,7,1),nrow=3)
sigma=matrix(c(3,1,2,1,4,5,2,5,9),byrow=T,nrow=3)
exp=t(a)%*%mu
exp
variance=t(a)%*%sigma%*%a
variance
#------------------------------------------------------------------------
mu=matrix(c(2,4,3),nrow=3)
sigma=matrix(c(3,1,2,1,4,5,2,5,9),byrow=T,nrow=3)
A=matrix(c(1,2,1,1,1,1,1,-2,-1),byrow=T,nrow=3)
A
exp=(A%*%mu)
exp
D=A%*%sigma%*%t(A)
D
#--------------------------------------------------------------------------
B=matrix(c(1,1,1,1,-1,1),byrow=T,nrow=2)
A=matrix(c(1,2,1,1,1,1,1,-2,-1),byrow=T,nrow=3)
mu=matrix(c(2,4,3),nrow=3)
sigma=matrix(c(3,1,2,1,4,5,2,5,9),byrow=T,nrow=3)
expZ=(B%*%mu)
expZ
DispY=B%*%sigma%*%t(B)
DispY;
COVyz=A%*%sigma%*%t(B)
COVyz
#--------------------------------------------------------------------------



install.packages('matlib')
library("matlib")
mu=matrix(c(2,4,5),nrow=3,byrow=T)
sigma=matrix(c(3,1,2,1,4,4,2,4,9),nrow=3,byrow=T)
A=matrix(c(1,4,2,4,5,6,2,6,7),nrow=3,byrow=T)
exp=drop(tr(A%*%sigma)+t(mu)%*%A%*%mu)
exp
#-----------------------------------------------------------------------------
n=10
x1=0:n
s=0
for(i in 0:n)
{
  for(j in 0:(n-i))
  {
    p=dmultinom(c(i,j,10-i-j),10,c(0.3,0.4,0.3),log=F)
    print(c(i,j,10-i-j,p))
    s=s+dmultinom(c(i,j,10-i-j),10,c(0.3,0.4,0.3),log=F)
  }
}
s
#------------------------------------------------------------------------------
#Mosaicplot
install.packages('vcd')
library("vcd")
data=HairEyeColor
mosaic(data,highlighting="Sex",highlighting_fill=c("blue","pink"),main="MosaicPlot Of HairEyecolor",direction=c("v","h","v"))
mosaic(data,highlighting="Sex",highlighting_fill=c("blue","pink"),main="MosaicPlot Of HairEyecolor")
mosaicplot(data)
#to change order of categorical variables
d=as.data.frame(data)
mosaic(~Eye+Hair+Sex,data=d,highlighting_fill=c("red","black"),main="MosaicPlot Of HairEyecolor",direction=c("v","h","v"))



labs=round(prop.table(HairEyeColor),3)
labs

mosaic(HairEyeColor,highlighting="Sex",highlighting_fill=c("green","pink"),main="MosaicPlot Of HairEyecolor",direction=c("v","h","v"),pop=F)
labeling_cells(text=labs,margin=0)(HairEyeColor)
#Comments:-
#there seems to be relationship between hair and eye color
#brown is most common type of hair color
#brown is most common type of eye color
#brown is most common hair color,red is least common in males and females
#black hair is most common in males blonde is most common hair color in females
#-----------------------------------------
#joint distribution of x1,x2.x column gives probability(23/02/2023)
x1=c(0,0,0,0,0,0,1,1,1,2)
x2=c(0,0,0,1,1,2,0,0,1,0)
x3=c(0,1,2,0,1,0,0,1,0,0)
p=c(0.04,0.08,0.04,0.16,0.16,0.16,0.08,0.08,0.16,0.04)
data=data.frame(x1,x2,x3,p)
aggregate(data$p,by=list(x1=x1,x2=x2),sum)
#-----------------------------------------------------
#marginal prob distribution of x1
aggregate(data$p,by=list(x1=x1),sum)
#marginal prob distribution of x3 given x1=1 and x2=0(conditional distribution of x3 given x1=1 and x2=0)
x3_=x3[x1==1&x2==0]
prob=p[x1==1&x2==0]/sum(p[x1==1&x2==0])
cprob=data.frame(x3_,prob)
cprob
#--------------------------------------------------------------
install.packages('pracma')
library(pracma)
f=function(x1,x2,x3)
{
  (12/7)*((x1^2)+x2*x3)
}
integral3(f,0,1,0,1,0,1)
#-------------------------------------------------------
#marginal distribution(integration)of x1,x2(27/02/2023)
library("Ryacas")
x1=ysym("x1")
x2=ysym("x2")
x3=ysym("x3")
f=(12/7)*(x1^2+x2*x3)
integrate(f,x3,lower=0,upper=1)
#--------------------------------------------------
#marginal distribution(integration)of x1,x3
x1=ysym("x1")
x2=ysym("x2")
x3=ysym("x3")
f=(12/7)*(x1^2+x2*x3)
integrate(f,x2,0,1)
#----------------------------------------------------
#marginal distribution(integration)of x1
x1=ysym("x1")
x2=ysym("x2")
x3=ysym("x3")
f=(12/7)*(x1^2+x2*x3)
integrate(integrate(f,x3,0,1),x2,0,1)
#----------------------------------------------------------------------
#marginal diustribution of x1,x3,x4
x1=ysym("x1")
x2=ysym("x2")
x3=ysym("x3")
x4=ysym("x4")
f=(3/4)*(x1^2+x2^2+x3^2+x4^2)
integrate(f,x2,0,1)
install.packages('Ryacas')
library("Ryacas")
#-----------------------------------------------------------------------
#marginal distribution of x1,x2
x1=ysym("x1")
x2=ysym("x2")
x3=ysym("x3")
x4=ysym("x4")
f=(3/4)*(x1^2+x2^2+x3^2+x4^2)
integrate(integrate(f,x4,0,1),x3,0,1)
#-------------------------------------------------------------------------
#marginal disttribution of x1
x1=ysym("x1")
x2=ysym("x2")
x3=ysym("x3")
x4=ysym("x4")
f=(3/4)*(x1^2+x2^2+x3^2+x4^2)
integrate(integrate(integrate(f,x3,0,1),x4,0,1),x2,0,1)
#----------------------------------------------------------------------------
#Q.1(multinomial)
dmultinom(c(4,0,0),4,c(1/3,2/5,4/15))
dmultinom(c(3,1,0),4,c(1/3,2/5,4/15))
#___________________________________________
#Q.2
#(i)
dmultinom(c(4,2,1,1),8,c(0.5,0.3,0.1,0.1))
#(ii)
dbinom(3,4,5/6)
dbinom(2,4,5/6)
#-----------------------------------------------

a=matrix(c(1,1,1),nrow=3,byrow=T)
S=matrix(c(9,1,5,1,4,3,5,3,16),nrow=3,byrow=T)
t(a)%*%S%*%a
pnorm(6,9,sqrt(47))

x2=matrix(c(1,2),nrow=2,byrow=T)
mu2=matrix(c(4,3),nrow=2,byrow=T)
S12=matrix(c(1,5),nrow=1,byrow=T)
S21=t(S12)
S22=matrix(c(4,3,3,16),nrow=2,byrow=T)
mu=2+S12%*%solve(S22)%*%(x2-mu2)
mu
S11=9
variance=S11-S12%*%solve(S22)%*%S21
variance
#install.packages('condMVNorm')
#library("condMVNorm")

#conditional mean and variance of multivar normal disitribution
condMVN(mean=c(2,4,3),sigma=S,dependent.ind=1,given.ind=c(2,3),X.given=c(1,2))
condMVN(mean=c(2,4,3),sigma=1,dependent.ind=c(1,2),given.ind=3,X.given=2)
#to get desired prob
pcmvnorm(lower=1,upper=Inf,mean=c(2,3,4),sigma=S,dependent.ind=1,given.ind=c(2,3),X.given=c(1,2))

##chi-sq-qq-plot####
install.packages('MVN')
library(MVN)
install.packages('mvtnorm')
library(mvtnorm)
d=rmvnorm(1000,c(2,5,0),sigma=matrix(c(9,1,2,1,3,1,2,1,1),ncol=3))
result=mvn(data=d,multivariatePlot="qq",showOutliers=T)
result
v=iris
v
par(mfrow=c(2,2))
result1=mvn(data=iris,subset="Species",multivariatePlot="qq",showOutliers=T)
result1
#FROM BOTH TEST STAT AND QQ PLOT(HIGHER DEVIATIONS OF POINTS ABOUT THE LINE),P-VALUE<0.05 SO SETOSA DOESN;T SATISY MVN DISTRIBUTION

#SPIDER-WEB CHART

install.packages('fmsb')
library("fmsb")


max=c(100,100,100,100)
min=c(0,0,0,0)
value=c(99,56,84,91)
df=rbind(max,min,value)
df=as.data.frame(df)
colnames(df)=c("math","physics","stat","csc")
df
radarchart(df,pcol="blue",plwd=3)
radarchart(df,pcol="blue",pfcol=rgb(1,0,0,0.24),plwd=3)

radarchart(df,axistype=4,pcol="blue",pfcol=rgb(1,0,0,0.24),plwd=3,caxislabels=seq(0,100,25))


max=c(100,100,100,100)
min=c(0,0,0,0)
df1=data.frame(math=c(100,94,89,74),stat=c(99,89,78,88),phy=c(89,97,92,56),csc=c(67,45,78,80))
df2=rbind(max,min,df1)
colnames(df2)=c("math","physics","stat","csc")
rownames=c("max","min","ram","sam","don","clarke")
df2

#spider web chart for 4 srudents 
values=data.frame(math=c(100,94,89,74),
                  stat=c(99,89,78,88),
                  physics=c(89,97,92,56),
                  csc=c(67,45,78,77))
data=rbind(max,min,values)
colnames(data)=c("math","stat","physics","csc")

colors_border=c("red","blue","green","black")
areas=c(rgb(1,0,0,0.15),
        rgb(0,1,0,0.15),
        rgb(0,0,1,0.15),
        rgb(1,1,0,0.15))

radarchart(data,
           axistype = 4,
           pcol=colors_border,
           pfcol = areas,
           plwd=3,
           caxislabels = c(0,100,25))

legend(x=0.95,y=1.3,legend=c("Mason","Joe","Dave","Satyaki"),pch=20,col=colors_border,text.col = "black")




par(mfrow=c(2,2))
radarchart(data[c(1:3),],
           axistype = 4,
           pcol="red",
           pfcol = areas,
           plwd=3,
           caxislabels = c(0,100,25))
legend(x=0.95,y=1,legend=c("Spandan"),pch=20,col=colors_border,text.col = "black")
radarchart(data[c(1,2,4),],
           axistype = 4,
           pcol="blue",
           pfcol = areas,
           plwd=3,
           caxislabels = c(0,100,25))
legend(x=0.95,y=1,legend=c("Ashika"),pch=20,col=colors_border,text.col = "black")
radarchart(data[c(1,2,5),],
           axistype = 4,
           pcol="green",
           pfcol = areas,
           plwd=3,
           caxislabels = c(0,100,25))
legend(x=0.95,y=1,legend=c("Neha"),pch=20,col=colors_border,text.col = "black")
radarchart(data[c(1,2,6),],
           axistype = 4,
           pcol="black",
           pfcol = areas,
           plwd=3,
           caxislabels = c(0,100,25))
legend(x=0.95,y=1,legend=c("Kanchan"),pch=20,col=colors_border,text.col = "black")









